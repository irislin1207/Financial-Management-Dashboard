# 餘裕 — 自架版部署步驟

個人金流管理 PWA。單頁應用、Firebase 儲存、Google 登入、可安裝、可離線。

## 檔案

| 檔案 | 用途 | 要不要改 |
|---|---|---|
| `index.html` | App 本體 | 不用 |
| `firebase.js` | 儲存層 | **要**，貼上你的 firebaseConfig |
| `manifest.json` | PWA 設定 | 不用 |
| `sw.js` | 離線快取 | 不用 |
| `yuyu-import-template.xlsx` | Excel 匯入範本，設定頁的「下載範本」會用到 | 不用 |
| `make-icons.html` | 產生圖示 | 用完可刪 |
| `firestore.rules` | 安全規則 | 貼到 Firebase 主控台 |

---

## 一、建 Firebase 專案（約 10 分鐘）

1. 開 <https://console.firebase.google.com> → **新增專案**
   - 名稱隨意，例如 `yuyu`
   - Google Analytics 可以關掉，用不到

2. 左側 **建構 → Firestore Database → 建立資料庫**
   - 模式選 **正式版**（規則等一下會換掉）
   - 位置選 `asia-east1`（台灣）

3. 左側 **建構 → Authentication → 開始使用**
   - 選 **Google** → 啟用 → 填一個支援用電子郵件 → 儲存

4. 左側齒輪 **專案設定 → 一般**
   - 捲到「你的應用程式」→ 點 **`</>`（網頁）**
   - 暱稱隨意，**不要**勾 Firebase Hosting
   - 註冊後會看到 `firebaseConfig`，整段複製

5. 打開 `firebase.js`，把最上面那段 `firebaseConfig` 換成你複製的

6. 回 Firebase 主控台 **Firestore Database → 規則**
   - 把 `firestore.rules` 的內容整段貼上 → **發布**

7. **Authentication → 設定 → 已授權的網域**
   - 加入你的 GitHub Pages 網域，例如 `你的帳號.github.io`

---

## 二、產生圖示（1 分鐘）

用瀏覽器開 `make-icons.html`，按三個按鈕各下載一次，把
`icon-192.png`、`icon-512.png`、`icon-180.png` 放到同一個資料夾。

---

## 三、放上 GitHub Pages（約 5 分鐘）

```bash
# 在這個資料夾裡
git init
git add .
git commit -m "餘裕 v1"
git branch -M main
git remote add origin https://github.com/你的帳號/yuyu.git
git push -u origin main
```

GitHub 上 → **Settings → Pages**
- Source：`Deploy from a branch`
- Branch：`main` / `/ (root)` → Save

一兩分鐘後就能開 `https://你的帳號.github.io/yuyu/`

> repo 設 Private 也可以用 Pages（需要 GitHub Pro）。
> 想免費又不公開程式碼，改用 Cloudflare Pages 接私有 repo。

---

## 四、搬資料過去

1. 舊版（claude.ai artifact）→ 設定 → 系統設定 → 資料與備份 → **完整備份 · JSON**
2. 新版登入後 → 同一個位置 → 貼進「匯入」→ **從 JSON 覆蓋**（按兩次確認）

---

## 五、裝到手機

用手機瀏覽器開你的網址：

- **iPhone（Safari）**：分享 → 加入主畫面
- **Android（Chrome）**：選單 → 安裝應用程式

裝完是獨立視窗，沒有瀏覽器外框，離線也打得開。

---

## 之後要改程式

改完 `index.html` push 上去就好。這一版（2026-11-11）同時更新了 `index.html`、`sw.js`、`manifest.json`，並新增 `yuyu-import-template.xlsx`，四個檔案都要上傳。Service Worker 用的是「網路優先」，
所以重開 App 就會拿到新版，不會卡在舊的。

若真的卡住：手機上把 App 完全關掉再開；桌面 `Ctrl+Shift+R`。

---

## 已知限制

- **Firestore 單一文件上限 1 MiB**，整份資料約可裝 5,000–7,000 筆交易（約 4–6 年）。
  接近時要把交易按月拆成多份文件。
- **證券現值**需要即時股價，目前沒有接任何報價來源，只記總成本。
- `firebaseConfig` 會出現在前端原始碼裡，**這是正常的**——它不是密鑰，
  真正的防護是 `firestore.rules`。
